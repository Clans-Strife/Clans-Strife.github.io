<?php
echo <<<HTML
<div class="alert alert-error"><b>Внимание!</b><br>Во избежании проблем, в целях безопасности, проверка обновлений отключена!</div>
HTML;
?>